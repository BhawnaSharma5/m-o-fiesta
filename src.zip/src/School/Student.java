package School;

public class Student {
    private static GradeType grade;
    String name;
    Integer age;

    int count =1;
    int studentId;
    public Student(String name, Integer age, GradeType grade) {
        this.name = name;
        this.age = age;
        this.grade = grade;
        this.studentId= count;
        count++;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public static GradeType getGrade() {
        return grade;
    }

    public void setGrade(GradeType grade) {
        this.grade = grade;
    }

    public int getStudentId() {
        return studentId;
    }

    public  void  setStudentId(int studentId){
        this.studentId=studentId;
    }

}