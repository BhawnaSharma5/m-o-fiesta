package School;

public class AgeTooLowException extends Throwable{
}

