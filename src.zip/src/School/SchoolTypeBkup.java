package School;

public enum SchoolTypeBkup {

    PRESCHOOL("Preschool"),
    ELEMENTARY_SCHOOL("ElementarySchool"),
    MIDDLE_SCHOOL("MiddleSchool"),
    HIGH_SCHOOL("Highschool");


    private  String schoolName;

    SchoolTypeBkup(String schoolName) {
        this.schoolName = schoolName;
    }
}

