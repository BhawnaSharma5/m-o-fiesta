package School;

public class AgeNotCorrectException extends Throwable {
    public AgeNotCorrectException(String s) {
    }
}
