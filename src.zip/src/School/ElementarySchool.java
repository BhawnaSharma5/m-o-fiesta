package School;

import java.text.DecimalFormat;

public class ElementarySchool extends AbstractSchool{
    private double fee;
    private String grade;

    @Override
    public double chargefees(Student student) {
        grade=student.getGrade().name();
        if(grade.equals("GRADE_1")){
            fee= 100 * 1.5;

        }else if(grade.equals("SECOND_GRADE")){
            fee=(100 * 1.5)+(100 * 1.5)*0.30;
        }
        else if(grade.equals("THIRD_GRADE")){
            fee=((100 * 1.5)+(100 * 1.5)*0.30)+(((100 * 1.5)+(100 * 1.5)*0.30)*0.30);
        }
        else if(grade.equals("FOURTH_GRADE")){
            fee=((100 * 1.5)+(100 * 1.5)*0.30)+((((100 * 1.5)+(100 * 1.5)*0.30)*0.30) +(100 * 1.5)*0.30);

        } else if(grade.equals("FIFTH_GRADE")){
            fee=((100 * 1.5)+(100 * 1.5)*0.30)+(((100 * 1.5)+(100 * 1.5)*0.30)*0.30)+(((100 * 1.5)+(100 * 1.5)*0.30)*0.30);

        }
        return fee;
    }
}

