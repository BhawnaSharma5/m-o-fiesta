package School;

import static java.lang.Double.parseDouble;

public class HighSchool extends AbstractSchool{
    private double fee;
    private String grade;

    @Override
    public double chargefees(Student student) {
        grade=student.getGrade().name();
        if(grade.equals("NINTH_GRADE")){
            fee= 100 * 2;

        }else if(grade.equals("TENTH_GRADE")){
            fee=(100 * 2)+(100 * 2)*0.45;
        }
        else if(grade.equals("ELEVENTH_GRADE")){
            fee=((100 * 2)+(100 * 2)*0.45)+(((100 * 2)+(100 * 2)*0.45)*0.45);
        }
        else if(grade.equals("TWELVETH_GRADE")){
            fee=((100 * 2)+(100 * 2)*0.45)+((((100 * 2)+(100 * 2)*0.45)*0.45) +(100 * 2)*0.45);

        }
        return fee;
    }
}

