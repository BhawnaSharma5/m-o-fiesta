package School;

import java.text.DecimalFormat;

public class MiddleSchool extends AbstractSchool{
    private double fee;
    private String grade;

    @Override
    public double chargefees(Student student) {
        grade=student.getGrade().name();
        if(grade.equals("SIXTH_GRADE")){
            fee= 100 * 1.75;

        }else if(grade.equals("SEVENTH_GRADE")){
            fee=(100 * 1.75)+(100 * 1.75)*0.35;
        }
        else if(grade.equals("EIGHTTH_GRADE")){
            fee=((100 * 1.75)+(100 * 1.75)*0.35)+(((100 * 1.75)+(100 * 1.75)*0.35)*0.35);
        }
        return fee;
    }
}

