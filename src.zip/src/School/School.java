package School;

public interface School {
    Student admitStudent ( Student student) throws ClassFullException;
    double chargefees ( Student student);

}
