package School;

public class ClassFullException extends Exception{
}
