package School;

public class PreSchool extends AbstractSchool{
    private double fee;
    private String grade;

    @Override
    public double chargefees(Student student) {
        grade=student.getGrade().name();

        if(grade.equals("JK_GRADE")){
            fee= 100 * 1.1;

        }else if(grade.equals("SK_GRADE")) {
            fee = (100 * 1.1) + (100 * 1.1) * 0.25;
        }
        return fee;
    }
}

