package School;

public class GradeNotCorrectException extends Throwable {
}
