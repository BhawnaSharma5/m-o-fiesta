package School;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class AbstractSchool implements School {
    Map<GradeType, List<Student>> gradeToStudentsMap = new HashMap<>();

    public Student admitStudent(Student student) throws ClassFullException {
        if (gradeToStudentsMap.get(Student.getGrade()) == null) {
            List<Student> studentList = new ArrayList<>();
            studentList.add(student);
            gradeToStudentsMap.put(student.getGrade(), studentList);
            System.out.println(
                    "\n" +"Student " + student.name + "  \n " + "is admit into grade " + student.getGrade() + "\n" +
                    getClass() + "\n"+ "and student id is " + student.getStudentId()
                    +"  and school fees is "+ chargefees(student) + "\n");
        } else {
            List<Student> studentList = gradeToStudentsMap.get(student.getGrade());


                if (studentList.size() >= 3) {
                    throw new ClassFullException();
                }
                studentList.add(student);
                gradeToStudentsMap.put(student.getGrade(), studentList);


                System.out.println("Student " + student.name + " is admit into grade "
                        + student.getGrade() + " and school is " + getClass() +
                        " and student id is " + student.getStudentId()
                        +"and school fees is "+ chargefees(student) );
            }
            return student;


        }

}




