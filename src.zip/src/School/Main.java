package School;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

import static School.SchoolType.*;

public class Main {
    static School preSchool = new PreSchool();
    static School elementarySchool = new ElementarySchool();
    static School middleSchool = new MiddleSchool();
    static School highSchool = new HighSchool();

    public static void main(String[] args) {
        boolean flag = true;
        while (flag) {
            System.out.println("Welcome to School Admissions App, Press X for Exit");
            System.out.println("Enter the name of the student");
            Scanner scanner = new Scanner(System.in);
            String name = scanner.nextLine();
            if(name.equalsIgnoreCase("x")){
             flag= false;
               return;
            }
            System.out.println("Enter the DOB of the Student [mm/dd/yyyy]: ");
            String dob = scanner.nextLine();
            String arr[] = dob.split("/");
            int m = Integer.parseInt(arr[0]);
            int d = Integer.parseInt(arr[1]);
            int y = Integer.parseInt(arr[2]);
            LocalDate today = LocalDate.now();
            LocalDate birthDate = LocalDate.of(y, m, d);
            Period period = Period.between(birthDate, today);

            int age = period.getYears();

            System.out.println("Age of Student is : " + age);
            //Integer age = scanner.nextInt();
            System.out.println("student name is " + name + "  and age is " + age);
            //3. determine name is not too long/short , also age is not too low/high
            if (name.length() >= 25 || name.length() < 3) {
                System.out.println("name is too long or too short ");

            }
            if (age < 4 || age > 17) {
                System.out.println("age is too low or too high ");
            }

            //4. determineGradeBasedOnage()
            GradeType grade= null;
            try {
                grade = determineGradeBasedOnAge(age);
            } catch (AgeNotCorrectException e) {
                System.out.println(" age is not correct either its too high or too low");
            }
            //5. determineSchoolBasedOnGrade()
            SchoolType schoolType = null;
            try {
                schoolType = determineSchoolBasedOnGrade(grade);
            } catch (GradeNotCorrectException e) {
                System.out.println(" grade not correct , please fix");
            }
            //6. schooladmitStudent()
            Student student = new Student(name, age, grade);


            School school = retrieveSchoolObjectBasedOnSchoolType(schoolType);
            try {
                school.admitStudent(student);
            } catch (ClassFullException e) {
                System.out.println("Sorry the class for grade#" + grade + " is full, please try another student");
            }

            if(schoolType.equals(HIGH_SCHOOL)){
                new HighSchool().chargefees(student);
            }
            if(schoolType.equals(MIDDLE_SCHOOL)){
                new MiddleSchool().chargefees(student);
            }
            if(schoolType.equals(ELEMENTARY_SCHOOL)){
                new ElementarySchool().chargefees(student);
            }
            if(schoolType.equals(PRE_SCHOOL)){
                new PreSchool().chargefees(student);
            }

        }

    }
    public static SchoolType getschool() {
        return null;
    }

    public static GradeType getGrade() {
        return null;
    }

    public static School retrieveSchoolObjectBasedOnSchoolType(SchoolType schoolType) {
        switch (schoolType) {
            case HIGH_SCHOOL:
                return highSchool;
            case ELEMENTARY_SCHOOL:
                return elementarySchool;
            case MIDDLE_SCHOOL:
                return middleSchool;
            case PRE_SCHOOL:
                return preSchool;
            default:
                throw new IllegalArgumentException("  Wrong School Type  ");
        }
    }

    public static SchoolType determineSchoolBasedOnGrade(GradeType grade) throws GradeNotCorrectException {
        switch (grade) {
            case JK_GRADE:
            case SK_GRADE:
                return PRE_SCHOOL;
            case GRADE_1:
            case SECOND_GRADE:
            case THIRD_GRADE:
            case FOURTH_GRADE:
            case FIFTH_GRADE:
                return ELEMENTARY_SCHOOL;
            case SIXTH_GRADE:
            case SEVENTH_GRADE:
            case EIGHTTH_GRADE:
                return MIDDLE_SCHOOL;
            case NINTH_GRADE:
            case TENTH_GRADE:
            case ELEVENTH_GRADE:
            case TWELVETH_GRADE:
                return HIGH_SCHOOL;
            default:
                throw new GradeNotCorrectException();
        }
    }

    public static GradeType determineGradeBasedOnAge(int age) throws AgeNotCorrectException {
        System.out.println("determining grade done");
        switch (age) {
            case 4:
                return GradeType.JK_GRADE;
            case 5:
                return GradeType.SK_GRADE;
            case 6:
                return GradeType.GRADE_1;
            case 7:
                return GradeType.SECOND_GRADE;
            case 8:
                return GradeType.THIRD_GRADE;
            case 9:
                return GradeType.FOURTH_GRADE;
            case 10:
                return GradeType.FIFTH_GRADE;
            case 11:
                return GradeType.SIXTH_GRADE;
            case 12:
                return GradeType.SEVENTH_GRADE;
            case 13:
                return GradeType.EIGHTTH_GRADE;
            case 14:
                return GradeType.NINTH_GRADE;
            case 15:
                return GradeType.TENTH_GRADE;
            case 16:
                return GradeType.ELEVENTH_GRADE;
            case 17:
                return GradeType.TWELVETH_GRADE;
            default:
                throw new AgeNotCorrectException("age has to be between 4 and 17");

        }
    }
}