package School;

public class NameNotValidException extends Throwable {
}
