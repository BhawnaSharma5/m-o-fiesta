package School;

public class AgeTooHighException extends Throwable{
}
