package School;

public enum GradeTypeBkup {

      JK( "JK", SchoolTypeBkup.PRESCHOOL),
      SK( "SK", SchoolTypeBkup.PRESCHOOL),
    GRADE_1("1", SchoolTypeBkup.ELEMENTARY_SCHOOL),
    GRADE_2("2", SchoolTypeBkup.ELEMENTARY_SCHOOL);


    private String gradeName;
    private SchoolTypeBkup schoolTypeBkup;

    GradeTypeBkup(String gradeName, SchoolTypeBkup schoolTypeBkup) {
        this.gradeName = gradeName;
        this.schoolTypeBkup = schoolTypeBkup;
    }
}
